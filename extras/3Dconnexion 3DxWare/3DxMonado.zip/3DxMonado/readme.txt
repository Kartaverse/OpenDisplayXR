            3Dconnexion Add-In for Monado
            ======================================================

The "3Dconnexion Add-In for the Monado" software enables the customization of the 3Dconnexion 3D mice buttons and the control of device settings from within the application.


1. KNOWN ISSUES
---------------
- 3DxWare user configurations
If you have previously saved user configurations in 3Dconnexion 3DxWare prior to installing this add-in, you need to switch focus to the default configuration in order to appropriately display commands in the add-in and SpacePilot LCD.  You can do this by first opening the application, and then selecting 3DxWare Control Panel from your desktop or from "Programs" -> "3Dconnexion" -> "3Dconnexion 3DxWare" -> "Show 3Dconnexion Control Panel" and selecting "InstantNGP" in the "Configuration For" box.

2. REQUIREMENTS
---------------
This section lists the minimum requirements for the use of the "3Dconnexion Add-In for Monado".

- "Monado Service" OpenXR Runtime

- General System Requirements
As specified for Monado.


3. CHANGE LOG
-------------
For information on changes to the add-in, please refer to the "Release Notes" documentation available with software downloads at http://www.3Dconnexion.com/support/software/


4. TROUBLESHOOTING
------------------
In case of problems or questions regarding this 3Dconnexion add-in, please check the Support page on the 3Dconnexion web site:

http://www.3Dconnexion.com/support/


6. KEY MAPPINGS
---------------

Input	Hex	Axis	Function
---------------------------------------------
W	1A	HIDMultiAxis_Y	Dolly In D
S	16	HIDMultiAxis_Y	Dolly Out D
Q	14	HIDMultiAxis_Z	Track Down
E	08	HIDMultiAxis_Z	Track Up
A	04	HIDMultiAxis_X	Track Left D
D	07	HIDMultiAxis_X	Track Right D
---------------------------------------------
Up Arrow	52	HIDMultiAxis_Rx+	Tilt Up
Down Arrow	51	HIDMultiAxis_Rx-	Tilt Down
Left Arrow	50	HIDMultiAxis_Ry+	Pan Left
Right Arrow	4F	HIDMultiAxis_Ry-	Pan Right
---------------------------------------------
R	Fit	Reset Camera
F	Lock	Link controller position to camera pose


7. INPUT SPEED
-----------------
The Monado Service allows you to change the speed the camera moves in the scene. In the "Qwerty System" window, expand the "Qwerty HMD" section. Then enter the following preferred values:

hmd.movement_speed 0.04
hmd.look_speed 0.04


8. MONDAO SERVICE LAUNCHING
---------------------------
If you would like to control an OpenXR session with the SpaceMouse input hardware, the Mondao Service needs to be started with the "QWERTY" HMD device driver mode enabled. This can be done using the following environment variables:

P_OVERRIDE_ACTIVE_CONFIG=qwerty
QWERTY_ENABLE=1
XRT_DEBUG_GUI=1


A sample "start_service.bat" script would be:

@echo off

REM Specify the OpenXR configuration file
set XR_RUNTIME_JSON=%~dp0\bin\openxr_monado.json

REM Specify Monado environment variables
REM set P_OVERRIDE_ACTIVE_CONFIG=remote

REM Enable the Qwerty device driver
set P_OVERRIDE_ACTIVE_CONFIG=qwerty
set QWERTY_ENABLE=1
set XRT_DEBUG_GUI=1

REM Launch the Monado OpenXR based background service
%~dp0\bin\monado-service.exe

pause
